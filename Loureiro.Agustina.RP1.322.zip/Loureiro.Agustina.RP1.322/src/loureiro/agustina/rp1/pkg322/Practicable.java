package loureiro.agustina.rp1.pkg322;

public interface Practicable {
    public void practicaEnPareja();
}
