package loureiro.agustina.rp1.pkg322;

public class LoureiroAgustinaRP1322 {

    public static void main(String[] args) {
        
        Torneo torneo = new Torneo("UTN");

        Jugador j1 = new Singlista("Gaston Gaudio", 3, SuperficiePreferida.CEMENTO, 210);
        Jugador j2 = new Doblista("Roger Federer", 25, SuperficiePreferida.POLVO, 8);
        Jugador j3 = new Juvenil("Diego Schwartzman", 200, SuperficiePreferida.CESPED, true);
        Jugador j4 = new Singlista("Rafael Nadal", 50, SuperficiePreferida.POLVO, 180);

        torneo.agregarJugador(j1);
        torneo.agregarJugador(j2);
        torneo.agregarJugador(j3);
        torneo.agregarJugador(j4);

        torneo.mostrarJugadores();

        torneo.sacar(j1);
        torneo.sacar(j2);
        torneo.sacar(j3);

        torneo.practicaEnPareja(j2);
        torneo.practicaEnPareja(j3);
        torneo.practicaEnPareja(j1);

        torneo.filtrarPorSuperficie(SuperficiePreferida.POLVO);

        torneo.generarResumenPorTipo();

        try {
            Jugador dup = new Singlista("Gaston Gaudio", 3, SuperficiePreferida.CEMENTO, 210);
            torneo.agregarJugador(dup);
        } catch (JugadorDuplicadoException ex) {
            System.err.println("Error: " + ex.getMessage());
        }

    }
    
}
