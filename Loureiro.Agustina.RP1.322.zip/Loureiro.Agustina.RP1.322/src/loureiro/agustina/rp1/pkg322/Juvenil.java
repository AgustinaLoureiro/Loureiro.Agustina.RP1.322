package loureiro.agustina.rp1.pkg322;

public class Juvenil extends Jugador implements Practicable {
    
    private boolean poseeTutor;

    public Juvenil(String nombre, int ranking, SuperficiePreferida superficiePreferida, boolean poseeTutor) {
        super(nombre, ranking, superficiePreferida);
        this.poseeTutor = poseeTutor;
    }
    
    @Override
    public void practicaEnPareja() {
        System.out.println("Juvenil esta practicando con su pareja.");
    }

    @Override
    public void mostrarDatos() {
        System.out.println("Jugador: " + getNombre());
        System.out.println("Ranking: " + getRanking());
        System.out.println("Superficie preferida: " + getSuperficiePreferida());
        System.out.println("Tiene tutor deportivo: " + poseeTutor);
        System.out.println("-----");
    }
    
}
