package loureiro.agustina.rp1.pkg322;

public class Singlista extends Jugador implements Sacable {
    
    private int velocidadSaque;

    public Singlista(String nombre, int ranking, SuperficiePreferida superficiePreferida, int velocidadSaque) {
        super(nombre, ranking, superficiePreferida);
        this.velocidadSaque = velocidadSaque;
    }
    
    @Override
    public void sacar() {
        System.out.println("Singlista esta realizando un saque.");
    }

    @Override
    public void mostrarDatos() {
        System.out.println("Jugador: " + getNombre());
        System.out.println("Ranking: " + getRanking());
        System.out.println("Superficie preferida: " + getSuperficiePreferida());
        System.out.println("Velocidad del saque: " + velocidadSaque);
        System.out.println("-----");
    }
    
}
