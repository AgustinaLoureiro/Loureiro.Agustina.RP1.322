package loureiro.agustina.rp1.pkg322;

public interface Sacable {
    public void sacar();
}
