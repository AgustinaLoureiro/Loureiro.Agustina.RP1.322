package loureiro.agustina.rp1.pkg322;

public enum SuperficiePreferida {
    POLVO,
    CESPED,
    CEMENTO
}
