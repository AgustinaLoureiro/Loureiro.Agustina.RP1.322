package loureiro.agustina.rp1.pkg322;

public class JugadorNuloException extends RuntimeException {
    public JugadorNuloException() {
        super();
    }
    public JugadorNuloException(String m){
        super(m);
    }
}
