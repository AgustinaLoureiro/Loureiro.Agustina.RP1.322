package loureiro.agustina.rp1.pkg322;

import java.util.ArrayList;

public class Torneo {
    
    private String nombre;
    private ArrayList<Jugador> jugadores;

   public Torneo(String nombre) {
    this.nombre = nombre;
    this.jugadores = new ArrayList<>();
}
    
    private void validarNulo(Object o) {
        if (o == null){
            throw new JugadorNuloException("Jugador inexistente");
        }
    }

    private void validarRepetido(Jugador j) {
        validarNulo(j);
        if (jugadores.contains(j)) {
            throw new JugadorDuplicadoException("El jugador '" + j.getNombre() + "' ya se encuentra registrado en el torneo.");
        }
    }

    public void agregarJugador(Jugador jugador) {
        validarRepetido(jugador);
        jugadores.add(jugador);
        System.out.println("Jugador agregado: " + jugador.getNombre());
    }

    public void mostrarJugadores() {
        if (jugadores.isEmpty()) {
            System.out.println("No hay jugadores registrados.");
            return;
        }
        for (Jugador j : jugadores) {
            j.mostrarDatos();
        }
    }
    
    public void sacar(Jugador j){
        validarNulo(j);
        if (!jugadores.contains(j)) {
            System.out.println("El jugador no está registrado en el torneo.");
            return;
        }
        if (j instanceof Sacable s) {
            s.sacar();
        } else {
            System.out.println("El jugador " + j.getNombre() + " no puede realizar saque.");
        }
    }
    
    public void practicaEnPareja(Jugador j){
        validarNulo(j);
        if (!jugadores.contains(j)) {
            System.out.println("El jugador no está registrado en el torneo.");
            return;
        }
        if (j instanceof Practicable p) {
            p.practicaEnPareja();
        } else {
            System.out.println("El jugador " + j.getNombre() + " no puede practicar en pareja.");
        }
    }
    
    public ArrayList<Jugador> filtrarPorSuperficie(SuperficiePreferida s) {
        ArrayList<Jugador> filtro = new ArrayList<>();
        for (Jugador j : jugadores) {
            if (j.getSuperficiePreferida() == s) filtro.add(j);
        }
        if (filtro.isEmpty()) {
            System.out.println("No hay jugadores para la superficie: " + s);
        } else {
            System.out.println("Jugadores que prefieren " + s + ":");
            for (Jugador j : filtro) System.out.println(" - " + j.getNombre() + " (ranking " + j.getRanking() + ")");
        }
        return filtro;
    }
    
    public void generarResumenPorTipo() {
        int singlistas = 0, doblistas = 0, juveniles = 0;
        for (Jugador j : jugadores) {
            if (j instanceof Singlista) singlistas++;
            else if (j instanceof Doblista) doblistas++;
            else if (j instanceof Juvenil) juveniles++;
        }
        System.out.println("Resumen por tipo:");
        System.out.println("Singlistas: " + (singlistas > 0 ? singlistas : "0"));
        System.out.println("Doblistas: " + (doblistas > 0 ? doblistas : "0"));
        System.out.println("Juveniles: " + (juveniles > 0 ? juveniles : "0"));
    }
    
}
