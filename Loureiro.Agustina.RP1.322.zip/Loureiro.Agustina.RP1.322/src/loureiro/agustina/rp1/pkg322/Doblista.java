package loureiro.agustina.rp1.pkg322;

public class Doblista extends Jugador implements Sacable, Practicable {
    
    private int indiceCoordinacion;

    public Doblista(String nombre, int ranking, SuperficiePreferida superficiePreferida, int indiceCoordinacion) {
        super(nombre, ranking, superficiePreferida);
        validarCoordinacion(indiceCoordinacion);
        this.indiceCoordinacion = indiceCoordinacion;
    }
    
    private void validarCoordinacion(int c){
        if(c < 1 || c > 10){
        throw new IllegalArgumentException("Coordinacion incorrecta, debe ser entre 1 y 10.");
        }
    }

    public int getIndiceCoordinacion() {
        return indiceCoordinacion;
    }
    
    @Override
    public void sacar() {
        System.out.println("Doblista esta realizando un saque.");
    }
    
    @Override
    public void practicaEnPareja() {
        System.out.println("Doblista esta practicando con su pareja.");
    }

    @Override
    public void mostrarDatos() {
        System.out.println("Jugador: " + getNombre());
        System.out.println("Ranking: " + getRanking());
        System.out.println("Superficie preferida: " + getSuperficiePreferida());
        System.out.println("Indice de coordinacion con su pareja: " + indiceCoordinacion);
        System.out.println("-----");
    }
    
}
