package loureiro.agustina.rp1.pkg322;

import java.util.Objects;

public abstract class Jugador {
    
    private String nombre;
    private int ranking;
    private SuperficiePreferida superficiePreferida;

    public Jugador(String nombre, int ranking, SuperficiePreferida superficiePreferida) {
        this.nombre = Objects.requireNonNull(nombre, "El nombre no puede ser nulo");
        this.ranking = ranking;
        this.superficiePreferida = Objects.requireNonNull(superficiePreferida, "La superficie no puede ser nula");
    }

    public String getNombre() {
        return nombre;
    }

    public int getRanking() {
        return ranking;
    }

    public SuperficiePreferida getSuperficiePreferida() {
        return superficiePreferida;
    }
        
    public abstract void mostrarDatos();
    
    @Override
    public boolean equals(Object o){
        if (o == null || !(o instanceof Jugador j)){
            return false;
        }
        return this.ranking == j.ranking && this.nombre.equalsIgnoreCase(j.nombre);
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(nombre.toLowerCase(), ranking);
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Nombre: ").append(nombre);
        sb.append(", Ranking: ").append(ranking);
        sb.append(", Superficie: ").append(superficiePreferida);
        return sb.toString();
    }
    
}
