package loureiro.agustina.rp1.pkg322;

public class JugadorDuplicadoException extends RuntimeException {
    public JugadorDuplicadoException() {
        super();
    }
    public JugadorDuplicadoException(String m){
        super(m);
    }
}
